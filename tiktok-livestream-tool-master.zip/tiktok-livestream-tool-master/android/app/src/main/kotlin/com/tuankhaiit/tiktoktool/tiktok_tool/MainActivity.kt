package com.tuankhaiit.tiktoktool.tiktok_tool

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
