class K {
  static const double borderRadius = 12;
  static const double edgePadding = 16;
  static const double buttonHeight = 46;
}
