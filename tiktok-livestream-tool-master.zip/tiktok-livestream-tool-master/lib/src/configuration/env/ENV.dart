class ENV {
  ENV._();

  // TODO: Launch Flutter module only
  static late final bool singleLaunch;

  static late final bool isDebug;

  static const String socketServer = 'http://home.tuankhaiit.com:8081';
  static const String apiServer = 'https://tiktok.tuankhaiit.com';
}
