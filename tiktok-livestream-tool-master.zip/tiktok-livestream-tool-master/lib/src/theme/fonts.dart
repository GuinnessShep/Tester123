
class XFonts {
  static const String myriadpro = 'myriadpro';
  static const String roboto = 'Roboto';
}